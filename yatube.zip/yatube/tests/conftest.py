pytest_plugins = [
    'fixtures.fixture_user',
    'fixtures.fixture_data',
]
